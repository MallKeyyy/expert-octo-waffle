# Sync Dark Volume Bell (OriginOS 5 & 6 LSPosed Module)

Recolors the yellow OriginOS volume silencer bell button (`#FFE56A`) to a dark tile **synchronized directly with your volume panel / slider dark color** and a crisp light bell icon.

## Build the APK on Mobile (No PC Needed)

1. Unzip `SyncDarkVolumeBell-LSPosed.zip`.
2. Push or upload the unzipped folder contents to a GitHub repository (make sure `.github/workflows/build-apk.yml` is included).
3. Open the **Actions** tab on GitHub -> **Build Sync Dark Volume Bell APK** -> download **SyncDarkVolumeBell-LSPosed-APK** (`app-release.apk`).
4. Install `app-release.apk`, open **LSPosed**, enable **Sync Dark Volume Bell** for:
   - **System UI** (`com.android.systemui`)
   - **vivo System UI Plugin** (`com.vivo.systemuiplugin`)
5. Restart System UI (or reboot).

> **Note:** Uses a local compile-only Xposed API stub (`:xposed-api-stub`), so GitHub Actions builds cleanly with zero external Xposed Maven downtime.
