package com.mallkeyyy.syncdarkvolumebell;

import android.app.Dialog;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableWrapper;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Locale;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * OriginOS 5 / 6 LSPosed Module:
 * Synchronizes the yellow volume silencer/ringer bell button to the dark color
 * of the active OriginOS volume slider / volume panel container.
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "[SyncDarkVolumeBell] ";
    private static final String PKG_SYSTEMUI = "com.android.systemui";
    private static final String PKG_VIVO_PLUGIN = "com.vivo.systemuiplugin";

    // Fallback palette sampled from OriginOS dark volume slider & panel
    private static final int FALLBACK_DARK_BG = 0xE6222224;      // Dark volume track / panel tone
    private static final int FALLBACK_STROKE = 0x26FFFFFF;       // Subtle OriginOS glass edge
    private static final int FALLBACK_ICON_LIGHT = 0xFFF2F2F7;   // Crisp light bell icon

    // Live synchronized palette updated dynamically from the volume panel view tree
    private static volatile int sSyncedDarkBg = FALLBACK_DARK_BG;
    private static volatile int sSyncedIconColor = FALLBACK_ICON_LIGHT;
    private static volatile boolean sHasLoggedSample = false;

    // Prevent re-entrancy when our own recolor triggers setBackground / setTint hooks
    private static final ThreadLocal<Boolean> sApplying = new ThreadLocal<Boolean>() {
        @Override
        protected Boolean initialValue() {
            return Boolean.FALSE;
        }
    };

    // Track dialogs we already attached a layout listener to
    private static final WeakHashMap<View, Boolean> sObservedRoots = new WeakHashMap<>();

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!PKG_SYSTEMUI.equals(lpparam.packageName) && !PKG_VIVO_PLUGIN.equals(lpparam.packageName)) {
            return;
        }

        XposedBridge.log(TAG + "Loaded in " + lpparam.packageName);

        hookDialogShow();
        hookViewBackgrounds();
        hookImageViewTints();
    }

    private void hookDialogShow() {
        try {
            XposedHelpers.findAndHookMethod(Dialog.class, "show", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    Dialog dialog = (Dialog) param.thisObject;
                    if (dialog == null) return;

                    String clsName = dialog.getClass().getName().toLowerCase(Locale.ROOT);
                    Window window = dialog.getWindow();
                    if (window == null) return;
                    final View decor = window.getDecorView();
                    if (decor == null) return;

                    boolean likelyVolume = clsName.contains("volume")
                            || clsName.contains("audio")
                            || clsName.contains("sound")
                            || hasVolumeViews(decor, 0);

                    if (!likelyVolume) return;

                    decor.post(() -> processVolumeRoot(decor));
                    attachLayoutObserver(decor);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hookDialogShow error: " + t);
        }
    }

    private void attachLayoutObserver(final View root) {
        synchronized (sObservedRoots) {
            if (Boolean.TRUE.equals(sObservedRoots.get(root))) {
                return;
            }
            sObservedRoots.put(root, Boolean.TRUE);
        }

        ViewTreeObserver vto = root.getViewTreeObserver();
        if (vto != null && vto.isAlive()) {
            vto.addOnGlobalLayoutListener(() -> {
                if (root.getVisibility() == View.VISIBLE) {
                    processVolumeRoot(root);
                }
            });
        }
    }

    private void hookViewBackgrounds() {
        try {
            XposedHelpers.findAndHookMethod(View.class, "setBackgroundDrawable", Drawable.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (Boolean.TRUE.equals(sApplying.get())) return;
                    View view = (View) param.thisObject;
                    handlePotentialBellView(view);
                }
            });

            XposedHelpers.findAndHookMethod(View.class, "setBackgroundTintList", ColorStateList.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (Boolean.TRUE.equals(sApplying.get())) return;
                    View view = (View) param.thisObject;
                    handlePotentialBellView(view);
                }
            });

            XposedHelpers.findAndHookMethod(View.class, "setBackgroundColor", int.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (Boolean.TRUE.equals(sApplying.get())) return;
                    View view = (View) param.thisObject;
                    handlePotentialBellView(view);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hookViewBackgrounds error: " + t);
        }
    }

    private void hookImageViewTints() {
        try {
            XposedHelpers.findAndHookMethod(ImageView.class, "setImageDrawable", Drawable.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (Boolean.TRUE.equals(sApplying.get())) return;
                    ImageView iv = (ImageView) param.thisObject;
                    if (isBellIconOrParent(iv)) {
                        applyBellIconTint(iv);
                    }
                }
            });

            XposedHelpers.findAndHookMethod(ImageView.class, "setImageTintList", ColorStateList.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (Boolean.TRUE.equals(sApplying.get())) return;
                    ImageView iv = (ImageView) param.thisObject;
                    if (isBellIconOrParent(iv)) {
                        applyBellIconTint(iv);
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hookImageViewTints error: " + t);
        }
    }

    private void handlePotentialBellView(View view) {
        if (view == null || !isInVolumeHierarchy(view)) return;

        // First see if we can sample a fresher dark volume color from the root
        View root = view.getRootView();
        if (root != null) {
            samplePaletteFromVolumeTree(root);
        }

        if (isRingerBellCandidate(view)) {
            applySyncedDarkStyle(view);
        }
    }

    private void processVolumeRoot(View root) {
        if (root == null || Boolean.TRUE.equals(sApplying.get())) return;
        try {
            // 1. Synchronize palette from the volume sliders & panel container first
            samplePaletteFromVolumeTree(root);
            // 2. Recolor the silencer bell button and its bell icon
            recolorVolumeTree(root, 0);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "processVolumeRoot error: " + t);
        }
    }

    private void samplePaletteFromVolumeTree(View root) {
        int[] bestDarkTrack = new int[]{0}; // [0] = color, 0 if not found
        int[] bestDarkPanel = new int[]{0};
        int[] bestLabelColor = new int[]{0};

        collectVolumeColors(root, 0, bestDarkTrack, bestDarkPanel, bestLabelColor);

        int chosenBg = 0;
        if (bestDarkTrack[0] != 0) {
            chosenBg = bestDarkTrack[0];
        } else if (bestDarkPanel[0] != 0) {
            chosenBg = bestDarkPanel[0];
        }

        if (chosenBg != 0) {
            // Ensure comfortable opacity so the dark button feels solid like the slider track
            int alpha = Color.alpha(chosenBg);
            if (alpha < 0xCC) {
                chosenBg = Color.argb(0xE6, Color.red(chosenBg), Color.green(chosenBg), Color.blue(chosenBg));
            }
            if (chosenBg != sSyncedDarkBg) {
                sSyncedDarkBg = chosenBg;
                if (!sHasLoggedSample) {
                    sHasLoggedSample = true;
                    XposedBridge.log(TAG + String.format("Synchronized dark color: #%08X", sSyncedDarkBg));
                }
            }
        }

        if (bestLabelColor[0] != 0) {
            sSyncedIconColor = bestLabelColor[0];
        }
    }

    private void collectVolumeColors(View view, int depth, int[] bestDarkTrack, int[] bestDarkPanel, int[] bestLabelColor) {
        if (view == null || depth > 14) return;

        String name = getSafeResourceName(view);
        String cls = view.getClass().getSimpleName().toLowerCase(Locale.ROOT);

        // Skip the ringer bell itself while sampling
        if (isRingerName(name) || isRingerName(cls)) {
            return;
        }

        // Sample volume label text color (e.g., "Media", "Ringtone") for crisp icon sync
        if (bestLabelColor[0] == 0 && view instanceof TextView) {
            int textColor = ((TextView) view).getCurrentTextColor();
            if (Color.alpha(textColor) >= 0xAA && luminance(textColor) > 0.65f) {
                bestLabelColor[0] = Color.argb(0xFF, Color.red(textColor), Color.green(textColor), Color.blue(textColor));
            }
        }

        boolean isSlider = (view instanceof SeekBar)
                || name.contains("slider")
                || name.contains("seekbar")
                || name.contains("progress")
                || cls.contains("slider")
                || cls.contains("seekbar");

        boolean isPanel = name.contains("volume_dialog")
                || name.contains("dialog_rows")
                || name.contains("volume_panel")
                || name.contains("container")
                || name.contains("panel");

        if (isSlider || isPanel) {
            Integer extracted = extractDarkNeutralColor(view);
            if (extracted != null) {
                if (isSlider && bestDarkTrack[0] == 0) {
                    bestDarkTrack[0] = extracted;
                } else if (isPanel && bestDarkPanel[0] == 0) {
                    bestDarkPanel[0] = extracted;
                }
            }
        }

        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;
            for (int i = 0; i < vg.getChildCount(); i++) {
                collectVolumeColors(vg.getChildAt(i), depth + 1, bestDarkTrack, bestDarkPanel, bestLabelColor);
            }
        }
    }

    private void recolorVolumeTree(View view, int depth) {
        if (view == null || depth > 14) return;

        if (isRingerBellCandidate(view)) {
            applySyncedDarkStyle(view);
        }

        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;
            for (int i = 0; i < vg.getChildCount(); i++) {
                recolorVolumeTree(vg.getChildAt(i), depth + 1);
            }
        }
    }

    private void applySyncedDarkStyle(View target) {
        if (target == null) return;
        sApplying.set(Boolean.TRUE);
        try {
            int darkColor = sSyncedDarkBg;
            Drawable bg = target.getBackground();

            // Clear any yellow background tint list first
            ColorStateList bgTint = target.getBackgroundTintList();
            if (bgTint != null && isYellowish(bgTint.getDefaultColor())) {
                target.setBackgroundTintList(ColorStateList.valueOf(darkColor));
            }

            if (bg != null) {
                Drawable updated = recolorBackgroundDrawable(bg, darkColor, target);
                if (updated != null) {
                    target.setBackground(updated);
                }
            } else {
                target.setBackground(createSyncedRoundedDrawable(darkColor, target));
            }

            // Recolor bell icon(s) inside or on the target
            if (target instanceof ImageView) {
                applyBellIconTint((ImageView) target);
            } else if (target instanceof ViewGroup) {
                recolorChildIcons((ViewGroup) target, 0);
            }
        } finally {
            sApplying.set(Boolean.FALSE);
        }
    }

    private void recolorChildIcons(ViewGroup group, int depth) {
        if (group == null || depth > 4) return;
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            if (child instanceof ImageView) {
                applyBellIconTint((ImageView) child);
            } else if (child instanceof ViewGroup) {
                recolorChildIcons((ViewGroup) child, depth + 1);
            }
        }
    }

    private void applyBellIconTint(ImageView iv) {
        if (iv == null) return;
        sApplying.set(Boolean.TRUE);
        try {
            int iconColor = sSyncedIconColor;
            iv.setImageTintList(ColorStateList.valueOf(iconColor));
            iv.setColorFilter(iconColor, PorterDuff.Mode.SRC_IN);
        } finally {
            sApplying.set(Boolean.FALSE);
        }
    }

    private Drawable recolorBackgroundDrawable(Drawable bg, int darkColor, View target) {
        try {
            Drawable mutated = bg.mutate();
            if (mutated instanceof GradientDrawable) {
                GradientDrawable gd = (GradientDrawable) mutated;
                gd.setColor(darkColor);
                float density = target.getResources().getDisplayMetrics().density;
                gd.setStroke(Math.max(1, (int) (density * 0.8f)), FALLBACK_STROKE);
                return gd;
            }
            if (mutated instanceof ColorDrawable) {
                return createSyncedRoundedDrawable(darkColor, target);
            }
            if (mutated instanceof RippleDrawable) {
                RippleDrawable rd = (RippleDrawable) mutated;
                for (int i = 0; i < rd.getNumberOfLayers(); i++) {
                    Drawable layer = rd.getDrawable(i);
                    if (layer instanceof GradientDrawable) {
                        ((GradientDrawable) layer.mutate()).setColor(darkColor);
                    } else if (layer != null) {
                        layer.mutate().setColorFilter(darkColor, PorterDuff.Mode.SRC_IN);
                    }
                }
                return rd;
            }
            if (mutated instanceof LayerDrawable) {
                LayerDrawable ld = (LayerDrawable) mutated;
                for (int i = 0; i < ld.getNumberOfLayers(); i++) {
                    Drawable layer = ld.getDrawable(i);
                    if (layer instanceof GradientDrawable) {
                        ((GradientDrawable) layer.mutate()).setColor(darkColor);
                    } else if (layer != null) {
                        layer.mutate().setColorFilter(darkColor, PorterDuff.Mode.SRC_IN);
                    }
                }
                return ld;
            }
            // Fallback for custom OriginOS drawables: clean rounded-square matching tile shape
            return createSyncedRoundedDrawable(darkColor, target);
        } catch (Throwable ignored) {
            return createSyncedRoundedDrawable(darkColor, target);
        }
    }

    private GradientDrawable createSyncedRoundedDrawable(int darkColor, View target) {
        float density = target.getResources().getDisplayMetrics().density;
        int minDim = Math.min(target.getWidth(), target.getHeight());
        float radius = (minDim > 0) ? (minDim * 0.28f) : (density * 18f);

        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(radius);
        gd.setColor(darkColor);
        gd.setStroke(Math.max(1, (int) (density * 0.8f)), FALLBACK_STROKE);
        return gd;
    }

    private boolean isRingerBellCandidate(View view) {
        if (view == null) return false;
        String name = getSafeResourceName(view);
        String cls = view.getClass().getSimpleName().toLowerCase(Locale.ROOT);

        // Exclude volume sliders themselves
        if (view instanceof SeekBar || name.contains("slider") || name.contains("seekbar")) {
            return false;
        }

        if (isRingerName(name) || isRingerName(cls)) {
            return true;
        }

        // Color-based detection for OriginOS yellow silencer button (#FFE56A / #FFD94A)
        Integer bgColor = extractPrimaryColor(view);
        if (bgColor != null && isYellowish(bgColor)) {
            int w = view.getWidth();
            int h = view.getHeight();
            if (w == 0 || h == 0) {
                return true; // Not laid out yet, still yellow inside volume dialog
            }
            float ratio = (float) w / (float) h;
            return ratio >= 0.65f && ratio <= 1.55f;
        }
        return false;
    }

    private boolean isBellIconOrParent(ImageView iv) {
        if (iv == null || !isInVolumeHierarchy(iv)) return false;
        if (isRingerBellCandidate(iv)) return true;
        if (iv.getParent() instanceof View) {
            View p1 = (View) iv.getParent();
            if (isRingerBellCandidate(p1)) return true;
            if (p1.getParent() instanceof View) {
                return isRingerBellCandidate((View) p1.getParent());
            }
        }
        return false;
    }

    private boolean isRingerName(String s) {
        if (s == null || s.isEmpty()) return false;
        return s.contains("ringer")
                || s.contains("silent")
                || s.contains("silence")
                || s.contains("mute")
                || s.contains("vibrate")
                || s.contains("bell")
                || s.contains("audio_mode");
    }

    private boolean isInVolumeHierarchy(View view) {
        View curr = view;
        int steps = 0;
        while (curr != null && steps < 12) {
            String name = getSafeResourceName(curr);
            String cls = curr.getClass().getName().toLowerCase(Locale.ROOT);
            if (name.contains("volume") || cls.contains("volume")) {
                return true;
            }
            if (curr.getParent() instanceof View) {
                curr = (View) curr.getParent();
            } else {
                break;
            }
            steps++;
        }
        return false;
    }

    private boolean hasVolumeViews(View view, int depth) {
        if (view == null || depth > 6) return false;
        String name = getSafeResourceName(view);
        String cls = view.getClass().getName().toLowerCase(Locale.ROOT);
        if (name.contains("volume") || cls.contains("volume")) {
            return true;
        }
        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;
            for (int i = 0; i < vg.getChildCount(); i++) {
                if (hasVolumeViews(vg.getChildAt(i), depth + 1)) {
                    return true;
                }
            }
        }
        return false;
    }

    private Integer extractDarkNeutralColor(View view) {
        // Check SeekBar progress background track first
        if (view instanceof SeekBar) {
            Drawable prog = ((SeekBar) view).getProgressDrawable();
            Integer c = extractDarkNeutralFromDrawable(prog, 0);
            if (c != null) return c;
        }
        ColorStateList tint = view.getBackgroundTintList();
        if (tint != null) {
            int c = tint.getDefaultColor();
            if (isDarkNeutral(c)) return c;
        }
        return extractDarkNeutralFromDrawable(view.getBackground(), 0);
    }

    private Integer extractDarkNeutralFromDrawable(Drawable d, int depth) {
        if (d == null || depth > 5) return null;
        Integer c = extractColorFromDrawable(d);
        if (c != null && isDarkNeutral(c)) {
            return c;
        }
        if (d instanceof LayerDrawable) {
            LayerDrawable ld = (LayerDrawable) d;
            for (int i = 0; i < ld.getNumberOfLayers(); i++) {
                Integer sub = extractDarkNeutralFromDrawable(ld.getDrawable(i), depth + 1);
                if (sub != null) return sub;
            }
        } else if (d instanceof DrawableWrapper) {
            return extractDarkNeutralFromDrawable(((DrawableWrapper) d).getDrawable(), depth + 1);
        } else if (d instanceof ClipDrawable || d instanceof InsetDrawable || d instanceof StateListDrawable) {
            Drawable current = d.getCurrent();
            if (current != d) {
                return extractDarkNeutralFromDrawable(current, depth + 1);
            }
        }
        return null;
    }

    private Integer extractPrimaryColor(View view) {
        ColorStateList tint = view.getBackgroundTintList();
        if (tint != null && Color.alpha(tint.getDefaultColor()) > 0x40) {
            return tint.getDefaultColor();
        }
        return extractColorFromDrawable(view.getBackground());
    }

    private Integer extractColorFromDrawable(Drawable d) {
        if (d == null) return null;
        if (d instanceof ColorDrawable) {
            return ((ColorDrawable) d).getColor();
        }
        if (d instanceof GradientDrawable) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ColorStateList csl = ((GradientDrawable) d).getColor();
                if (csl != null) return csl.getDefaultColor();
            }
        }
        if (d instanceof ShapeDrawable) {
            return ((ShapeDrawable) d).getPaint().getColor();
        }
        if (d instanceof LayerDrawable) {
            LayerDrawable ld = (LayerDrawable) d;
            for (int i = 0; i < ld.getNumberOfLayers(); i++) {
                Integer sub = extractColorFromDrawable(ld.getDrawable(i));
                if (sub != null && Color.alpha(sub) > 0x40) return sub;
            }
        }
        if (d instanceof DrawableWrapper) {
            return extractColorFromDrawable(((DrawableWrapper) d).getDrawable());
        }
        return null;
    }

    private boolean isYellowish(int color) {
        if (Color.alpha(color) < 0x50) return false;
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        float h = hsv[0];
        float s = hsv[1];
        float v = hsv[2];
        return h >= 32f && h <= 68f && s >= 0.28f && v >= 0.55f;
    }

    private boolean isDarkNeutral(int color) {
        if (Color.alpha(color) < 0x35) return false;
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        float lum = luminance(color);
        return lum >= 0.03f && lum <= 0.38f && hsv[1] <= 0.35f;
    }

    private float luminance(int color) {
        return (0.2126f * Color.red(color) + 0.7152f * Color.green(color) + 0.0722f * Color.blue(color)) / 255f;
    }

    private String getSafeResourceName(View view) {
        if (view == null) return "";
        int id = view.getId();
        if (id == View.NO_ID || id == 0) return "";
        try {
            return view.getResources().getResourceEntryName(id).toLowerCase(Locale.ROOT);
        } catch (Resources.NotFoundException | Throwable ignored) {
            return "";
        }
    }
}
